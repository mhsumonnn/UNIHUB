<?php include 'header.php'?>

<?php
	
?>


<section class="main-section-area">
   <!--====== MAIN SECTION AREA START ======-->
   <div class="container">
      <div class="row">
         <div class="col-md-9 ">
            <div class="panel panel-default">
               <div class="edit-user-profile-area">

                  <div class="edit-user-profile-header text-center">
                     <p class="edit-user-profile-text">Edit Profile</p>
                  </div>

                  <div class="panel-body">
                     <div class="box box-info">
                        <div class="box-body">
                           <div class="col-md-4 col-sm-6 col-xs-12">
                              <div class="text-center">
                                 <img alt="User Pic" src="assets/images/nobody_m.original.jpg" id="profile-image2" class="img-thumbnail img-responsive"> 
                                 <input id="profile-image-upload" class="hidden" type="file">
                              </div>
                              <br>
                           </div>
                           <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
                              <form class="form-horizontal" action="includes/useredit.inc.php" method="POST"  role="form">
                                 <div class="form-group">
                                    <label class="col-lg-3 control-label">First name:</label>
                                    <div class="col-lg-8">
                                       <input class="form-control" value="John" type="text">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-lg-3 control-label">Last name:</label>
                                    <div class="col-lg-8">
                                       <input class="form-control" value="Doe" type="text">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-lg-3 control-label">Email:</label>
                                    <div class="col-lg-8">
                                       <input class="form-control" value="example@gmail.com" type="text">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label">Username:</label>
                                    <div class="col-md-8">
                                       <input class="form-control" value="JohnDoe" type="text">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label">Password:</label>
                                    <div class="col-md-8">
                                       <input class="form-control" value="11111122333" type="password">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label">Confirm password:</label>
                                    <div class="col-md-8">
                                       <input class="form-control" value="11111122333" type="password">
                                    </div>
                                 </div>
                                 <div class="form-group">
                                    <label class="col-md-3 control-label"></label>
                                    <div class="col-md-8">
                                       <input class="btn save-chg-btn" value="Save Changes" type="button">
                                       <span></span>
                                       <input class="btn cancle-btn" value="Cancel" type="reset">
                                    </div>
                                 </div>
                              </form>
                           </div>
                           <!-- /.box-body -->
                        </div>
                        <!-- /.box -->
                     </div>
                  </div>
               </div>
            </div>
         </div>
         
         <?php include 'rightbar.php';?>

      </div>
      <!--row div END-->
   </div>
   <!--container div END-->
</section>
<!--====== MAIN SECTION AREA END ======-->

<?php include 'footer.php'?>