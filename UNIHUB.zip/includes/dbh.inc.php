<?php

$dbServerName = "localhost";
$dbUserName = "root";
$dbPassword = "";
$dbName = "unihub";

$conn = mysqli_connect($dbServerName, $dbUserName, $dbPassword, $dbName);

?>